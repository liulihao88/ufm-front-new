import{x as e}from"./index-3beNfkrN.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
