import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-yQ7W9sdE.js";import"./index-Ce6-vpa1.js";export{m as default};
