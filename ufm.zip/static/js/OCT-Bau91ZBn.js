import{_ as m}from"./OCT.vue_vue_type_script_setup_true_lang-BDmTomVx.js";import"./index-kyINX625.js";export{m as default};
