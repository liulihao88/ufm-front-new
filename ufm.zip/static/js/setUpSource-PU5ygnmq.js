import{_ as m}from"./setUpSource.vue_vue_type_script_setup_true_lang-DN1bxpwu.js";import"./index-C2vp-hrZ.js";export{m as default};
