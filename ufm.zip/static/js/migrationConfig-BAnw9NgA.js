import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-Cd68dAav.js";import"./textCommon-CxOJCKiK.js";import"./index-C9a_XeES.js";export{o as default};
