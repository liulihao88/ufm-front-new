import{x as e}from"./index-BgzT56Ah.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
