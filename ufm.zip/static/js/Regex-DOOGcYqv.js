import{_ as m}from"./Regex.vue_vue_type_script_setup_true_lang-Cok2bczw.js";import"./index-DPXMJw2c.js";export{m as default};
