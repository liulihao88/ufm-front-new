import{_ as m}from"./Replace.vue_vue_type_script_setup_true_lang-BCp118fH.js";import"./index-C2vp-hrZ.js";export{m as default};
