import{_ as m}from"./workConfig.vue_vue_type_script_setup_true_lang-3u6yYzVI.js";import"./index-kyINX625.js";export{m as default};
