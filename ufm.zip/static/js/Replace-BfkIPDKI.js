import{_ as m}from"./Replace.vue_vue_type_script_setup_true_lang-B65fo3e3.js";import"./index-kyINX625.js";export{m as default};
