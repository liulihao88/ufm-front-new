import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-COTl8gqx.js";import"./index-3beNfkrN.js";export{m as default};
