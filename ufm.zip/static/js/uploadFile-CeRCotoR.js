import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-Cfd_lq00.js";import"./index-3beNfkrN.js";export{m as default};
