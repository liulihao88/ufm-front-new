import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-BmJYpvHK.js";import"./index-DiMrlKPy.js";export{m as default};
