import{_ as m}from"./newAddBucket.vue_vue_type_script_setup_true_lang-pv0N0g_S.js";import"./index-C9a_XeES.js";export{m as default};
