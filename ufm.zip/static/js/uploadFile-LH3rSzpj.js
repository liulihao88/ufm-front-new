import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-Bx3A9ucg.js";import"./index-DiMrlKPy.js";export{m as default};
