import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-BKULTAJQ.js";import"./index-DiMrlKPy.js";export{m as default};
