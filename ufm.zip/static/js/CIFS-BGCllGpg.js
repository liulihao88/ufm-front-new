import{_ as m}from"./CIFS.vue_vue_type_script_setup_true_lang-CMxbpGDv.js";import"./index-kyINX625.js";export{m as default};
