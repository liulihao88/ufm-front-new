import{_ as m}from"./NFS.vue_vue_type_script_setup_true_lang-Ds6d_lQB.js";import"./index-C9a_XeES.js";export{m as default};
