import{_ as m}from"./setUpSource.vue_vue_type_script_setup_true_lang-BgeNmox6.js";import"./index-DiMrlKPy.js";export{m as default};
