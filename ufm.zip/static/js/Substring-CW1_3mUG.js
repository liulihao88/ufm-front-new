import{_ as m}from"./Substring.vue_vue_type_script_setup_true_lang-mNkpGqm9.js";import"./index-DiMrlKPy.js";export{m as default};
