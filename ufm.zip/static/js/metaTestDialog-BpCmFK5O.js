import{_ as m}from"./metaTestDialog.vue_vue_type_script_setup_true_lang-DdHR3fLi.js";import"./index-3beNfkrN.js";export{m as default};
