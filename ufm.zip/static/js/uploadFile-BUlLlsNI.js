import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-BpmPQYFA.js";import"./index-C2vp-hrZ.js";export{m as default};
