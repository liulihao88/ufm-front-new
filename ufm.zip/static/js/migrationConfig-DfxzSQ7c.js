import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-BkruP3zP.js";import"./textCommon-DlJ1grx4.js";import"./index-Ce6-vpa1.js";export{o as default};
