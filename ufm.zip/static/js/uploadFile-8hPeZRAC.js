import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-DTgP8imx.js";import"./index-BgzT56Ah.js";export{m as default};
