import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-D2s6_JNJ.js";import"./textCommon-QjXmsF6p.js";import"./index-3beNfkrN.js";export{o as default};
