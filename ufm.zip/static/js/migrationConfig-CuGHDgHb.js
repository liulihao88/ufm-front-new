import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-CtQxvFhf.js";import"./textCommon-C8JOVO59.js";import"./index-DiMrlKPy.js";export{o as default};
