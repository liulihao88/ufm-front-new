import{_ as m}from"./metaTestDialog.vue_vue_type_script_setup_true_lang-CkR2NP1y.js";import"./index-BgzT56Ah.js";export{m as default};
