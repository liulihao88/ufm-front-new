import{_ as m}from"./NFS.vue_vue_type_script_setup_true_lang-Df7kz8w0.js";import"./index-BgzT56Ah.js";export{m as default};
