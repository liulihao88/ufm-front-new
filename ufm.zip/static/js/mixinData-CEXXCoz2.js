import{x as e}from"./index-DiMrlKPy.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
