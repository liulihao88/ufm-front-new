import{_ as m}from"./bucketOverviewHistory.vue_vue_type_script_setup_true_lang-dBLxMn3D.js";import"./index-C2vp-hrZ.js";export{m as default};
