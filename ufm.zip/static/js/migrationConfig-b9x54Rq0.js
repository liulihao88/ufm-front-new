import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-CK3SJgp7.js";import"./textCommon-BvTywyLz.js";import"./index-kyINX625.js";export{o as default};
