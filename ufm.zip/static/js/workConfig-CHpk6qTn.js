import{_ as m}from"./workConfig.vue_vue_type_script_setup_true_lang-CRQg1_CQ.js";import"./index-DiMrlKPy.js";export{m as default};
