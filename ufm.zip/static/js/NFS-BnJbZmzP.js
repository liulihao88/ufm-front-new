import{_ as m}from"./NFS.vue_vue_type_script_setup_true_lang-BfPbI-ZU.js";import"./index-3beNfkrN.js";export{m as default};
