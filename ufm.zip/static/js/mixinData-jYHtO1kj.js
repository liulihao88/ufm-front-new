import{x as e}from"./index-Ce6-vpa1.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
