import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-CetdwY1y.js";import"./index-Ce6-vpa1.js";export{m as default};
