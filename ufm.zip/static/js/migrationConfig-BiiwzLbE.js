import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-BYz1Ou9F.js";import"./textCommon-BMk1XtYF.js";import"./index-C2vp-hrZ.js";export{o as default};
