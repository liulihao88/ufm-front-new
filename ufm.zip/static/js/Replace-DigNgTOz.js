import{_ as m}from"./Replace.vue_vue_type_script_setup_true_lang-DHJRVptm.js";import"./index-BgzT56Ah.js";export{m as default};
