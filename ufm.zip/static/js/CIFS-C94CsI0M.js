import{_ as m}from"./CIFS.vue_vue_type_script_setup_true_lang-Bza_TRGy.js";import"./index-C9a_XeES.js";export{m as default};
