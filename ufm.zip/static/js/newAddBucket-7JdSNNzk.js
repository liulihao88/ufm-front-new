import{_ as m}from"./newAddBucket.vue_vue_type_script_setup_true_lang-CtiNHVwL.js";import"./index-DiMrlKPy.js";export{m as default};
