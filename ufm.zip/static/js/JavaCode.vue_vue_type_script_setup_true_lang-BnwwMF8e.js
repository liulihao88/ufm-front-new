import{d as c,E as l,x as t,Q as i,r as p,o as v,i as f}from"./index-C9a_XeES.js";const m=c({__name:"JavaCode",props:{data:{required:!0}},setup(s,{expose:r}){l();const n=s,o=t(null),e=t({code:`// value=source.getPath();
// value=source.getName();
// int i = value.lastIndexOf('.');
// if (i > 0) {
//    value = value.substring(i, value.length() - 5);
// } else {
//    value = "The Index is "+String.valueOf(i);
// }`});return i(()=>n.data,a=>{e.value=Object.assign({},e.value,a)},{immediate:!0}),r({form:e}),(a,d)=>{const u=p("g-script");return v(),f(u,{ref_key:"gScriptRef",ref:o,value:e.value.code},null,8,["value"])}}});export{m as _};
