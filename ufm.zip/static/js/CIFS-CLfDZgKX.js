import{_ as m}from"./CIFS.vue_vue_type_script_setup_true_lang-DtDR8z1E.js";import"./index-DPXMJw2c.js";export{m as default};
