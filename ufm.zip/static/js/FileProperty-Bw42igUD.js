import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-Bpvem96Q.js";import"./index-kyINX625.js";export{m as default};
