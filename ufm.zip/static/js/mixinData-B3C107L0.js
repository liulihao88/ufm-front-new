import{x as e}from"./index-C2vp-hrZ.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
