import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-BSQqC9D4.js";import"./index-BgzT56Ah.js";export{m as default};
