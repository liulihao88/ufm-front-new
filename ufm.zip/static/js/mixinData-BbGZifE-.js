import{x as e}from"./index-C9a_XeES.js";const r={setup(){return{valueKey:e("111111")}}};export{r as e};
