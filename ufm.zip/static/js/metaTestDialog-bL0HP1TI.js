import{_ as m}from"./metaTestDialog.vue_vue_type_script_setup_true_lang-D2IV2B0-.js";import"./index-DPXMJw2c.js";export{m as default};
