import{_ as m}from"./S3CS.vue_vue_type_script_setup_true_lang-CI7jnRE1.js";import"./index-C2vp-hrZ.js";export{m as default};
