import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-YCGKhuZ9.js";import"./textCommon-BCfqsdQa.js";import"./index-DPXMJw2c.js";export{o as default};
