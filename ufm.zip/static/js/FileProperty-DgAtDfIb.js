import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-BVpmpokS.js";import"./index-3beNfkrN.js";export{m as default};
