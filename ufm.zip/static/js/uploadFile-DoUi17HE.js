import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-BFNwvGIe.js";import"./index-C9a_XeES.js";export{m as default};
