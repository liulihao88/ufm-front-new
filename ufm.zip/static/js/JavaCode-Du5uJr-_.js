import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-BnwwMF8e.js";import"./index-C9a_XeES.js";export{m as default};
