import{_ as m}from"./OCT.vue_vue_type_script_setup_true_lang-YZ2SjnXm.js";import"./index-BgzT56Ah.js";export{m as default};
