import{_ as m}from"./workConfig.vue_vue_type_script_setup_true_lang-B7mOop_U.js";import"./index-DPXMJw2c.js";export{m as default};
