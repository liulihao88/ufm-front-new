import{_ as m}from"./uploadFile.vue_vue_type_script_setup_true_lang-DuapTBp_.js";import"./index-kyINX625.js";export{m as default};
