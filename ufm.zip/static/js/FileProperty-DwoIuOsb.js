import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-DYvQkyl8.js";import"./index-C9a_XeES.js";export{m as default};
