import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-DJaezgdt.js";import"./index-C2vp-hrZ.js";export{m as default};
