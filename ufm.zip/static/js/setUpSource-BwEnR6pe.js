import{_ as m}from"./setUpSource.vue_vue_type_script_setup_true_lang-BTgcCniF.js";import"./index-kyINX625.js";export{m as default};
