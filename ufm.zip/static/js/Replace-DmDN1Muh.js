import{_ as m}from"./Replace.vue_vue_type_script_setup_true_lang-DvnPdz1N.js";import"./index-C9a_XeES.js";export{m as default};
