import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-CVjmQ8VN.js";import"./index-DPXMJw2c.js";export{m as default};
