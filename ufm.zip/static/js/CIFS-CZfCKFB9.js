import{_ as m}from"./CIFS.vue_vue_type_script_setup_true_lang-Dz65DsN3.js";import"./index-DiMrlKPy.js";export{m as default};
