import{_ as m}from"./workConfig.vue_vue_type_script_setup_true_lang-C4I5PzwO.js";import"./index-Ce6-vpa1.js";export{m as default};
