import{_ as o}from"./migrationConfig.vue_vue_type_style_index_0_lang-B6tHX-DU.js";import"./textCommon-DOZ1Y1iy.js";import"./index-BgzT56Ah.js";export{o as default};
