import{_ as m}from"./FileProperty.vue_vue_type_script_setup_true_lang-DjZJqXn5.js";import"./index-BgzT56Ah.js";export{m as default};
