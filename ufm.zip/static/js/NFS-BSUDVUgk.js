import{_ as m}from"./NFS.vue_vue_type_script_setup_true_lang-DidU7K-m.js";import"./index-C2vp-hrZ.js";export{m as default};
