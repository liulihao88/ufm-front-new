import{_ as m}from"./JavaCode.vue_vue_type_script_setup_true_lang-Czkf07d8.js";import"./index-C2vp-hrZ.js";export{m as default};
