import{_ as m}from"./bucketOverviewHistory.vue_vue_type_script_setup_true_lang-DvTU3tui.js";import"./index-Ce6-vpa1.js";export{m as default};
