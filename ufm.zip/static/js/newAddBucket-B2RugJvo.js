import{_ as m}from"./newAddBucket.vue_vue_type_script_setup_true_lang-DLL189Cl.js";import"./index-C2vp-hrZ.js";export{m as default};
